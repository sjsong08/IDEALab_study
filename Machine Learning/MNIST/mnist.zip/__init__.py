from .loader import MNIST

__all__ = [MNIST, ]
